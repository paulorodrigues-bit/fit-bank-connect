const axios =
    require("axios");

const crypto =
    require("crypto");


function configuracaoObrigatoria(
    nome
) {

    const valor =
        process.env[nome];


    if (!valor) {

        throw new Error(
            `Configuração ausente: ${nome}`
        );
    }


    return valor;
}


function validarSandbox(
    url
) {

    if (
        process.env.ITAU_ENV ===
        "sandbox"
    ) {

        if (
            !url.includes(
                "sandbox"
            )
        ) {

            throw new Error(
                "Chamada bloqueada: ambiente Sandbox apontando para URL não Sandbox"
            );
        }
    }
}


function criarHeaders() {

    const token =
        configuracaoObrigatoria(
            "ITAU_SANDBOX_TOKEN"
        );


    const clientId =
        configuracaoObrigatoria(
            "ITAU_CLIENT_ID"
        );


    const correlationID =
        crypto.randomUUID();


    const flowID =
        crypto.randomUUID();


    const headers = {

        Authorization:
            `Bearer ${token}`,

        "x-itau-apikey":
            clientId,

        "x-itau-correlationID":
            correlationID,

        "x-itau-flowID":
            flowID,

        "Content-Type":
            "application/json"
    };


    return {
        headers,
        correlationID,
        flowID
    };
}


/*
=================================
EMISSÃO
=================================
*/

async function enviarBoletoItau(
    payload
) {

    const url =
        configuracaoObrigatoria(
            "ITAU_BOLETO_URL"
        );


    validarSandbox(
        url
    );


    const {
        headers,
        correlationID,
        flowID
    } =
        criarHeaders();


    if (
        process.env.ITAU_SEND_ENABLED !==
        "true"
    ) {

        return {

            enviado:
                false,

            ambiente:
                process.env.ITAU_ENV ||
                "sandbox",

            url,

            correlationID,

            flowID
        };
    }


    const resposta =
        await axios.post(

            url,

            payload,

            {
                headers,

                timeout:
                    15000
            }
        );


    return {

        enviado:
            true,

        ambiente:
            process.env.ITAU_ENV ||
            "sandbox",

        status:
            resposta.status,

        correlationID,

        flowID,

        resposta:
            resposta.data
    };
}


/*
=================================
CONSULTA
=================================
*/

async function consultarBoletoItau({
    idBeneficiario,
    codigoCarteira,
    nossoNumero
}) {

    const urlBase =
        configuracaoObrigatoria(
            "ITAU_BOLETO_CONSULTA_URL"
        );


    validarSandbox(
        urlBase
    );


    const {
        headers,
        correlationID,
        flowID
    } =
        criarHeaders();


    const resposta =
        await axios.get(

            urlBase,

            {

                headers,

                params: {

                    id_beneficiario:
                        idBeneficiario,

                    codigo_carteira:
                        codigoCarteira,

                    nosso_numero:
                        nossoNumero,

                    view:
                        "specific"
                },

                timeout:
                    15000
            }
        );


    return {

        ambiente:
            process.env.ITAU_ENV ||
            "sandbox",

        status:
            resposta.status,

        correlationID,

        flowID,

        resposta:
            resposta.data
    };
}


/*
=================================
BAIXA / CANCELAMENTO
=================================
*/

async function baixarBoletoItau({
    idBeneficiario,
    codigoCarteira,
    nossoNumero
}) {

    const urlBase =
        configuracaoObrigatoria(
            "ITAU_BOLETO_URL"
        );


    validarSandbox(
        urlBase
    );


    const idBoleto =
        `${idBeneficiario}${codigoCarteira}${nossoNumero}`;


    const url =
        `${urlBase}/${idBoleto}/baixa`;


    const {
        headers,
        correlationID,
        flowID
    } =
        criarHeaders();


    const resposta =
        await axios.patch(

            url,

            {},

            {

                headers,

                timeout:
                    15000
            }
        );


    return {

        ambiente:
            process.env.ITAU_ENV ||
            "sandbox",

        status:
            resposta.status,

        correlationID,

        flowID,

        resposta:
            resposta.data ||
            null
    };
}


module.exports = {

    enviarBoletoItau,

    consultarBoletoItau,

    baixarBoletoItau
};
