const axios = require("axios");


/*
=================================
CACHE DO ACCESS TOKEN

O Itaú informa validade padrão
de aproximadamente 5 minutos.

Não solicitamos novo token
a cada pagamento.
=================================
*/

let cacheToken = {

    accessToken:
        null,

    expiraEm:
        0
};


/*
=================================
CONFIGURAÇÃO
=================================
*/

function obterConfiguracao() {

    const ambiente =
        String(
            process.env
                .ITAU_SISPAG_ENV ||
            "sandbox"
        )
            .trim()
            .toLowerCase();


    const tokenUrl =
        String(
            process.env
                .ITAU_SISPAG_TOKEN_URL ||
            ""
        ).trim();


    const clientId =
        String(
            process.env
                .ITAU_SISPAG_CLIENT_ID ||
            ""
        ).trim();


    const privateKeyJwt =
        String(
            process.env
                .ITAU_SISPAG_PRIVATE_KEY_JWT ||
            ""
        ).trim();


    const erros =
        [];


    if (
        ambiente !==
        "sandbox"
    ) {

        erros.push(
            "Nesta etapa somente o ambiente Sandbox está habilitado"
        );
    }


    if (!tokenUrl) {

        erros.push(
            "ITAU_SISPAG_TOKEN_URL não configurada"
        );
    }


    if (!clientId) {

        erros.push(
            "ITAU_SISPAG_CLIENT_ID não configurado"
        );
    }


    if (!privateKeyJwt) {

        erros.push(
            "ITAU_SISPAG_PRIVATE_KEY_JWT não configurado"
        );
    }


    /*
    =================================
    PROTEÇÃO CONTRA PRODUÇÃO
    =================================
    */

    if (
        tokenUrl &&
        !tokenUrl.includes(
            "/sandbox/"
        )
    ) {

        erros.push(
            "A URL de autenticação não pertence ao Sandbox"
        );
    }


    if (
        erros.length >
        0
    ) {

        const erro =
            new Error(
                "Configuração OAuth SISPAG inválida"
            );


        erro.code =
            "FIT_SISPAG_AUTH_CONFIG_INVALIDA";


        erro.detalhes =
            erros;


        throw erro;
    }


    return {

        ambiente,

        tokenUrl,

        clientId,

        privateKeyJwt
    };
}


/*
=================================
TOKEN AINDA É VÁLIDO?
=================================
*/

function tokenEmCacheValido() {

    if (
        !cacheToken.accessToken
    ) {

        return false;
    }


    /*
    Renovamos com 30 segundos
    de margem.
    */

    const margem =
        30 * 1000;


    return (
        Date.now() <
        (
            cacheToken.expiraEm -
            margem
        )
    );
}


/*
=================================
ERRO SEGURO

Nunca devolvemos:
- JWT
- access_token
- Authorization
=================================
*/

function criarErroOAuth({
    status,
    resposta
}) {

    const mensagemBanco =

        resposta
            ?.error_description ||

        resposta
            ?.message ||

        resposta
            ?.mensagem ||

        resposta
            ?.error ||

        null;


    const erro =
        new Error(
            mensagemBanco ||
            "Falha na autenticação SISPAG"
        );


    erro.code =
        "FIT_SISPAG_AUTH_ERROR";


    erro.status =
        status;


    return erro;
}


/*
=================================
OBTER ACCESS TOKEN
=================================
*/

async function obterAccessTokenSispag({
    forcarRenovacao = false
} = {}) {

    if (
        !forcarRenovacao &&
        tokenEmCacheValido()
    ) {

        return {

            accessToken:
                cacheToken
                    .accessToken,

            origem:
                "cache",

            expiraEm:
                cacheToken
                    .expiraEm
        };
    }


    const configuracao =
        obterConfiguracao();


    const body =
        new URLSearchParams();


    /*
    Private Key JWT

    Mantemos estes valores
    isolados neste adapter.
    */

    body.set(
        "grant_type",
        "urn:ietf:params:oauth:grant-type:client_credentials"
    );


    body.set(
        "client_assertion_type",
        "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
    );


    body.set(
        "client_assertion",
        configuracao.privateKeyJwt
    );


    body.set(
        "client_id",
        configuracao.clientId
    );


    let resposta;


    try {

        resposta =
            await axios.post(

                configuracao.tokenUrl,

                body.toString(),

                {

                    headers: {

                        "Content-Type":
                            "application/x-www-form-urlencoded"
                    },

                    timeout:
                        15000,

                    validateStatus:
                        () => true
                }
            );


    } catch (erro) {

        const erroSeguro =
            new Error(
                "Falha de comunicação com o autorizador SISPAG"
            );


        erroSeguro.code =
            "FIT_SISPAG_AUTH_NETWORK_ERROR";


        throw erroSeguro;
    }


    if (
        resposta.status <
            200 ||

        resposta.status >=
            300
    ) {

        throw criarErroOAuth({

            status:
                resposta.status,

            resposta:
                resposta.data
        });
    }


    const accessToken =
        resposta
            ?.data
            ?.access_token;


    if (!accessToken) {

        const erro =
            new Error(
                "Itaú não retornou access_token"
            );


        erro.code =
            "FIT_SISPAG_TOKEN_INVALIDO";


        throw erro;
    }


    const expiresIn =
        Number(
            resposta
                ?.data
                ?.expires_in ||
            300
        );


    cacheToken = {

        accessToken,

        expiraEm:
            Date.now() +
            (
                expiresIn *
                1000
            )
    };


    return {

        accessToken,

        origem:
            "itau",

        expiresIn,

        expiraEm:
            cacheToken
                .expiraEm,

        tokenType:
            resposta
                ?.data
                ?.token_type ||
            "Bearer"
    };
}


/*
=================================
INVALIDAR CACHE
=================================
*/

function invalidarTokenSispag() {

    cacheToken = {

        accessToken:
            null,

        expiraEm:
            0
    };
}


/*
=================================
STATUS SEGURO

Nunca expõe o access_token.
=================================
*/

function resumirToken(
    resultado
) {

    return {

        sucesso:
            Boolean(
                resultado
                    ?.accessToken
            ),

        token_presente:
            Boolean(
                resultado
                    ?.accessToken
            ),

        origem:
            resultado
                ?.origem ||
            null,

        token_type:
            resultado
                ?.tokenType ||
            "Bearer",

        expires_in:
            resultado
                ?.expiresIn ||
            null,

        expira_em:
            resultado
                ?.expiraEm

                ? new Date(
                    resultado.expiraEm
                ).toISOString()

                : null
    };
}


module.exports = {

    obterConfiguracao,

    obterAccessTokenSispag,

    invalidarTokenSispag,

    resumirToken
};