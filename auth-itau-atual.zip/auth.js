const fs = require("fs");
const https = require("https");
const axios = require("axios");

let tokenCache = {
    accessToken: null,
    expiresAt: 0
};

function pegarConfiguracao(nome) {

    const valor = process.env[nome];

    if (!valor) {
        throw new Error(
            `Configuração obrigatória ausente: ${nome}`
        );
    }

    return valor;
}


async function obterAccessTokenItau() {

    const agora = Date.now();

    if (
        tokenCache.accessToken &&
        agora < tokenCache.expiresAt - 30000
    ) {
        return tokenCache.accessToken;
    }


    const certificado = fs.readFileSync(
        pegarConfiguracao("ITAU_CERT_PATH")
    );

    const chavePrivada = fs.readFileSync(
        pegarConfiguracao("ITAU_KEY_PATH")
    );


    const httpsAgent = new https.Agent({
        cert: certificado,
        key: chavePrivada,
        rejectUnauthorized: true,
        minVersion: "TLSv1.2"
    });


    const body = new URLSearchParams();

    body.append(
        "grant_type",
        "client_credentials"
    );

    body.append(
        "client_id",
        pegarConfiguracao("ITAU_CLIENT_ID")
    );

    body.append(
        "client_secret",
        pegarConfiguracao("ITAU_CLIENT_SECRET")
    );


    const resposta = await axios.post(
        pegarConfiguracao("ITAU_TOKEN_URL"),
        body.toString(),
        {
            httpsAgent,

            headers: {
                "Content-Type":
                    "application/x-www-form-urlencoded"
            },

            timeout: 10000
        }
    );


    if (!resposta.data.access_token) {
        throw new Error(
            "O Itaú não retornou um access_token"
        );
    }


    const expiresIn =
        Number(resposta.data.expires_in || 300);


    tokenCache = {
        accessToken: resposta.data.access_token,

        expiresAt:
            Date.now() + expiresIn * 1000
    };


    return tokenCache.accessToken;
}


module.exports = {
    obterAccessTokenItau
};